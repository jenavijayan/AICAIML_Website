export interface Project {
  id: string;
  title: string;
  description: string;
  category: 'Robotics' | 'AI Integration' | 'Machine Learning' | 'Academia';
  image: string;
  status: 'Ongoing' | 'Completed' | 'Upcoming';
  impact: string;
}

export interface UpcomingEvent {
  id: string;
  title: string;
  description: string;
  date: string; // e.g., "August 24, 2026"
  time: string;
  venue: string;
  category: 'Conference' | 'Workshop' | 'Hackathon' | 'FDP'; // Faculty Development Program
}

export interface NewsUpdate {
  id: string;
  title: string;
  summary: string;
  date: string;
  category: 'Announcement' | 'Press Release' | 'Industry News';
  readTime: string;
}

export interface Testimonial {
  id: string;
  name: string;
  designation: string;
  organization: string;
  quote: string;
  avatarUrl: string;
}

export interface Partner {
  id: string;
  name: string;
  type: 'Academic' | 'Corporate' | 'Government' | 'Startup';
  logoPlaceholder: string; // Tailored styled initials or simple vector logo
}

// Editable CMS-like data lists
export const initialProjects: Project[] = [
  {
    id: 'proj-1',
    title: 'National AI Skills & Certification Initiative (NASCI)',
    description: 'Empowering over 50,000 engineering students across tier-2 and tier-3 colleges in India with specialized certifications in Deep Learning and NLP, co-designed with industry leaders.',
    category: 'AI Integration',
    image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=800&q=80',
    status: 'Ongoing',
    impact: '50,000+ Students Certified'
  },
  {
    id: 'proj-2',
    title: 'AICAIML Autonomous Robotics Sandbox',
    description: 'An open-access simulation and testing lab network for students and startups to design, prototype, and build autonomous rovers and drone systems with cloud-integrated digital twins.',
    category: 'Robotics',
    image: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=800&q=80',
    status: 'Ongoing',
    impact: '120+ College Club Sandbox Labs'
  },
  {
    id: 'proj-3',
    title: 'AI Ethics & Algorithmic Fairness Whitepaper',
    description: 'A multi-stakeholder research collaboration presenting guidelines on ethical deployment of AI/ML systems in healthcare, finance, and public services within the Indian socio-demographic context.',
    category: 'Machine Learning',
    image: 'https://images.unsplash.com/photo-1507146426996-ef05306b995a?auto=format&fit=crop&w=800&q=80',
    status: 'Completed',
    impact: 'Adopted as National Advisory'
  },
  {
    id: 'proj-4',
    title: 'Smart Agriculture IoT & Edge ML Framework',
    description: 'Affordable IoT sensors and localized edge ML models developed in collaboration with leading agricultural universities to forecast soil moisture, crop disease, and optimize watering schedules.',
    category: 'Machine Learning',
    image: 'https://images.unsplash.com/photo-1560421683-6856ea585c78?auto=format&fit=crop&w=800&q=80',
    status: 'Upcoming',
    impact: 'Targeting 5,000 Farmers in Phase 1'
  }
];

export const initialEvents: UpcomingEvent[] = [
  {
    id: 'evt-1',
    title: 'National AI/ML & Robotics Congress 2026',
    description: 'The premier national assembly bringing together researchers, industrialists, startups, and policy-makers to discuss sustainable AI strategies, edge AI innovations, and autonomous robotics.',
    date: 'September 15-17, 2026',
    time: '09:00 AM - 05:30 PM',
    venue: 'Bharat Mandapam, New Delhi (Hybrid)',
    category: 'Conference'
  },
  {
    id: 'evt-2',
    title: 'AICAIML Smart India Robotics Hackathon',
    description: 'A 36-hour physical hackathon focusing on building hardware and software robotics solutions for disaster management, search & rescue, and automated waste segregation.',
    date: 'October 10-12, 2026',
    time: '08:00 AM onwards',
    venue: 'IIT Madras Research Park, Chennai',
    category: 'Hackathon'
  },
  {
    id: 'evt-3',
    title: 'National Faculty Development Program (FDP) on Generative AI',
    description: 'An intensive, AICTE-aligned 5-day professional development program teaching faculty members modern Generative AI pipelines, LLM fine-tuning, and prompt-engineering methodologies.',
    date: 'November 02-06, 2026',
    time: '10:00 AM - 04:00 PM',
    venue: 'Virtual (Zoom Platform)',
    category: 'FDP'
  },
  {
    id: 'evt-4',
    title: 'Hands-on Edge-ML on Microcontrollers Workshop',
    description: 'An advanced, practical workshop focusing on building and running tiny machine learning models (TinyML) on resource-constrained embedded systems and microcontrollers.',
    date: 'December 05, 2026',
    time: '10:00 AM - 05:00 PM',
    venue: 'IISc Innovation Center, Bengaluru',
    category: 'Workshop'
  }
];

export const initialNews: NewsUpdate[] = [
  {
    id: 'news-1',
    title: 'AICAIML Partners with 50+ Top Indian Universities for Centers of Excellence',
    summary: 'Establishing advanced research facilities in Machine Learning and Robotics to bridge the gap between academic theory and real-world industrial applicability.',
    date: 'July 14, 2026',
    category: 'Announcement',
    readTime: '3 min read'
  },
  {
    id: 'news-2',
    title: 'Ethics Board Proposes Unified National AI Guideline for Medical Diagnostic Tools',
    summary: 'AICAIML’s ethics advisory panel releases a comprehensive framework safeguarding patient privacy and model bias auditing standard operating procedures.',
    date: 'June 28, 2026',
    category: 'Press Release',
    readTime: '5 min read'
  },
  {
    id: 'news-3',
    title: 'Applications Open for the National AI Startup Acceleration Cohort 2027',
    summary: 'Providing up to 10 selected deep-tech startups with technical mentorship, sandboxed cloud credits, and direct investor matchmaking pipelines.',
    date: 'June 15, 2026',
    category: 'Announcement',
    readTime: '4 min read'
  }
];

export const initialTestimonials: Testimonial[] = [
  {
    id: 'test-1',
    name: 'Dr. Arpan Mukherjee',
    designation: 'Professor & Dean of Engineering',
    organization: 'Techno National Institute of Technology',
    quote: 'Collaborating with AICAIML to establish our robotics sandbox has transformed our curriculum. Our students are now building real autonomous systems and winning international hackathons.',
    avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80'
  },
  {
    id: 'test-2',
    name: 'Sneha Venkatesh',
    designation: 'Co-Founder & CEO',
    organization: 'Kinetics Robotics & Automations',
    quote: 'As an MSME member, the network forum has connected us directly with prime academic talent and research advisers. The policy dialogues help us align with emerging regulations seamlessly.',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80'
  },
  {
    id: 'test-3',
    name: 'Aman Deep Singh',
    designation: 'Lead ML Researcher',
    organization: 'Nvidia Research Labs India',
    quote: 'The academic conferences organized by AICAIML represent a rare nexus of rigorous peer-review and active corporate interest. An essential catalyst for Indias deep-tech rise.',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80'
  }
];

export const initialPartners: Partner[] = [
  { id: 'part-1', name: 'IIT Madras Research Park', type: 'Academic', logoPlaceholder: 'IITM' },
  { id: 'part-2', name: 'IISc Innovation Center', type: 'Academic', logoPlaceholder: 'IISc' },
  { id: 'part-3', name: 'Nvidia AI India', type: 'Corporate', logoPlaceholder: 'NVIDIA' },
  { id: 'part-4', name: 'Intel Technology India', type: 'Corporate', logoPlaceholder: 'INTEL' },
  { id: 'part-5', name: 'Microsoft for Startups', type: 'Corporate', logoPlaceholder: 'MS' },
  { id: 'part-6', name: 'CSIR - National Labs', type: 'Government', logoPlaceholder: 'CSIR' }
];
