import React, { useState } from 'react';
import { 
  Shield, Brain, Cpu, CpuIcon, Network, BookOpen, GraduationCap, 
  Award, ChevronRight, Briefcase, Users, Calendar, ArrowRight, 
  MapPin, Phone, Mail, HelpCircle, Check, Play, UserCheck, 
  MessageSquare, Loader2, Sparkles, Plus, Compass, Target, Star,
  Building, Server, CheckCircle
} from 'lucide-react';
import { 
  initialProjects, initialEvents, initialNews, initialTestimonials, 
  initialPartners, Project, UpcomingEvent, NewsUpdate, Testimonial 
} from '../cmsData';

interface HomeProps {
  setCurrentPage: (page: string) => void;
  setSelectedCategory: (cat: 'student' | 'msme' | 'corporate' | 'school' | 'university' | null) => void;
  onOpenRegisterEventModal: (event: UpcomingEvent) => void;
  onOpenDonationModal: () => void;
}

export default function Home({ 
  setCurrentPage, 
  setSelectedCategory, 
  onOpenRegisterEventModal,
  onOpenDonationModal
}: HomeProps) {
  
  // Local state for news list (supporting runtime CMS mock updates)
  const [newsList, setNewsList] = useState<NewsUpdate[]>(initialNews);
  const [showAddNews, setShowAddNews] = useState(false);
  const [newNews, setNewNews] = useState({ title: '', summary: '', category: 'Announcement' as any });
  const [isPublishing, setIsPublishing] = useState(false);

  // Local state for general enquiry form
  const [enquiryForm, setEnquiryForm] = useState({ name: '', email: '', phone: '', message: '' });
  const [honeypot, setHoneypot] = useState('');
  const [enquiryLoading, setEnquiryLoading] = useState(false);
  const [enquirySuccess, setEnquirySuccess] = useState<any | null>(null);
  const [enquiryError, setEnquiryError] = useState<string | null>(null);

  // Testimonial Carousel Index
  const [testimonialIndex, setTestimonialIndex] = useState(0);

  const handleNextTestimonial = () => {
    setTestimonialIndex((prev) => (prev + 1) % initialTestimonials.length);
  };

  const handlePrevTestimonial = () => {
    setTestimonialIndex((prev) => (prev - 1 + initialTestimonials.length) % initialTestimonials.length);
  };

  // Handle mock News publishing
  const handlePublishNews = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNews.title || !newNews.summary) return;
    setIsPublishing(true);
    try {
      const res = await fetch('/api/news/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...newNews, readTime: '3 min read' })
      });
      const data = await res.json();
      if (res.ok) {
        setNewsList([data.article, ...newsList]);
        setNewNews({ title: '', summary: '', category: 'Announcement' });
        setShowAddNews(false);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsPublishing(false);
    }
  };

  // Handle general enquiry form submit
  const handleEnquirySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setEnquiryLoading(true);
    setEnquirySuccess(null);
    setEnquiryError(null);

    try {
      const response = await fetch('/api/enquiry/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...enquiryForm, honeypot })
      });
      const resData = await response.json();
      if (!response.ok) {
        throw new Error(resData.error || 'Failed to submit enquiry.');
      }
      setEnquirySuccess(resData);
      setEnquiryForm({ name: '', email: '', phone: '', message: '' });
    } catch (err: any) {
      setEnquiryError(err.message || 'An unexpected error occurred.');
    } finally {
      setEnquiryLoading(false);
    }
  };

  const handleEnrollCategory = (cat: 'student' | 'msme' | 'corporate' | 'school' | 'university') => {
    setSelectedCategory(cat);
    setCurrentPage('membership');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div id="home-portal" className="animate-slideup">
      
      {/* SECTION 1: HERO BANNER */}
      <section className="relative bg-gradient-to-br from-[#071F3F] via-navy to-corp-blue text-white overflow-hidden py-24 md:py-32 border-b-4 border-gold">
        {/* Subtle geometric pattern overlay */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#14539A_1px,transparent_1px)] [background-size:16px_16px]"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 rounded-full border border-white/20 text-xs font-semibold text-gold tracking-wide">
              <Sparkles className="w-3.5 h-3.5" />
              <span>India’s Leading Autonomous AI & Robotics Council</span>
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold font-heading tracking-tight leading-tight">
              Advancing Deep Tech & Intelligent Systems for National Progress
            </h1>
            
            <p className="text-lg md:text-xl text-slate-300 leading-relaxed max-w-2xl font-sans">
              Connect • Learn • Innovate • Collaborate • Lead
            </p>
            
            <p className="text-sm md:text-base text-slate-300 max-w-xl">
              Fostering a nationwide ecosystem of students, researchers, startups, and institutions to accelerate Artificial Intelligence, Machine Learning, and Robotics education and technology transfer.
            </p>

            <div className="flex flex-wrap gap-4 pt-4">
              <button
                id="hero-btn-join"
                onClick={() => {
                  setCurrentPage('membership');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="px-6 py-3 bg-gold hover:bg-[#B37612] text-white text-base font-semibold rounded-md shadow-md transition-all flex items-center gap-2"
              >
                <span>Join Network Forum</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                id="hero-btn-explore"
                onClick={() => {
                  setCurrentPage('know-aicaiml');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="px-6 py-3 bg-white/10 border border-white/30 text-white hover:bg-white/20 text-base font-semibold rounded-md transition-all"
              >
                Know AICAIML
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 2: WHY AICAIML (Value Proposition) */}
      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:text-center max-w-3xl mx-auto space-y-4">
            <h2 className="text-base text-corp-blue font-bold tracking-wide uppercase font-heading">
              Why AICAIML
            </h2>
            <p className="mt-2 text-3xl font-extrabold tracking-tight text-navy sm:text-4xl font-heading">
              A Nationwide Coalition for Tomorrow’s Leaders
            </p>
            <p className="mt-4 text-lg text-slate-600 leading-relaxed">
              Become part of a nationwide community committed to advancing Artificial Intelligence, Machine Learning, and Robotics through education, research, innovation, entrepreneurship, and responsible technology development.
            </p>
          </div>
        </div>
      </section>

      {/* SECTION 3: DIGITAL ECOSYSTEM (Icon Grid) */}
      <section className="py-16 bg-pale-blue/50 border-y border-corp-blue/15">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-navy font-heading">The AICAIML Digital Ecosystem</h2>
            <p className="text-slate-600 text-sm mt-2">A integrated technology platform servicing academia, research, and corporate alliances.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { icon: Cpu, title: 'Advancement Hub', desc: 'Accelerating AI/ML, Robotics & Drone system research through distributed sandboxes and open simulation kits.' },
              { icon: BookOpen, title: 'National Curriculum Standard', desc: 'FDPs, skill development courses, and standardized certifications aligning technical education with deep-tech sectors.' },
              { icon: Network, title: 'Network Forum', desc: 'Seamlessly connects MSMEs, deep-tech startups, and academic researchers for rapid knowledge sharing and policy dialogues.' },
              { icon: Award, title: 'Certification Registry', desc: 'Cryptographically secured digital certification for graduates of approved AI CTE curriculum paths.' },
              { icon: Users, title: 'Campus Robotics Clubs', desc: 'Supporting over 500+ institutional student groups with funding support, competition kits, and expert mentoring.' },
              { icon: Brain, title: 'Responsible AI Framework', desc: 'Active research on model interpretability, bias evaluation, and fair algorithm deployment guidelines.' }
            ].map((eco, idx) => {
              const IconComp = eco.icon;
              return (
                <div key={idx} className="bg-white rounded-xl shadow-md p-6 border border-slate-100 hover:shadow-lg transition-all">
                  <div className="bg-pale-blue text-corp-blue p-3 rounded-lg w-fit mb-4">
                    <IconComp className="w-6 h-6" />
                  </div>
                  <h3 className="text-navy font-bold text-lg font-heading mb-2">{eco.title}</h3>
                  <p className="text-slate-600 text-sm leading-relaxed">{eco.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* SECTION 4: OUR PROJECTS (CMS Card Grid) */}
      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12">
            <div>
              <h2 className="text-base text-corp-blue font-bold uppercase tracking-wider font-heading">National Initiatives</h2>
              <h3 className="text-3xl font-extrabold text-navy font-heading mt-1">Our Core Projects</h3>
              <p className="text-slate-500 text-sm mt-1">Transforming technical ecosystems through direct execution frameworks.</p>
            </div>
            <button
              onClick={() => setCurrentPage('events-projects')}
              className="mt-4 md:mt-0 text-accent-sky hover:text-corp-blue font-semibold text-sm flex items-center gap-1.5"
            >
              <span>View All Projects</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {initialProjects.slice(0, 4).map((proj) => (
              <div key={proj.id} className="flex flex-col sm:flex-row gap-6 bg-slate-50 rounded-xl p-5 border border-slate-100 hover:bg-slate-100/50 transition-colors">
                <img 
                  src={proj.image} 
                  alt={proj.title} 
                  referrerPolicy="no-referrer"
                  className="w-full sm:w-40 h-32 object-cover rounded-lg shrink-0 bg-slate-200" 
                />
                <div className="space-y-2 flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-accent-sky uppercase tracking-widest">{proj.category}</span>
                    <span className="inline-flex items-center rounded-md bg-green-50 px-2 py-0.5 text-[10px] font-medium text-green-700 ring-1 ring-inset ring-green-600/20">{proj.status}</span>
                  </div>
                  <h4 className="text-navy font-bold text-base font-heading">{proj.title}</h4>
                  <p className="text-slate-600 text-xs leading-relaxed line-clamp-3">{proj.description}</p>
                  <p className="text-xs text-corp-blue font-semibold pt-1">Impact: {proj.impact}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 5: UPCOMING EVENTS (CMS List with CTAs) */}
      <section className="py-16 bg-navy text-white relative">
        <div className="absolute inset-0 opacity-5 bg-[radial-gradient(#FFFFFF_1px,transparent_1px)] [background-size:20px_20px]"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12">
            <div>
              <span className="text-xs uppercase text-gold font-bold tracking-widest">Connect & Engage</span>
              <h3 className="text-3xl font-extrabold font-heading text-white mt-1">Upcoming Events</h3>
              <p className="text-slate-300 text-sm mt-1">Register for executive seminars, robotics congresses, and AI hackathons.</p>
            </div>
            <button
              onClick={() => setCurrentPage('events-projects')}
              className="mt-4 md:mt-0 text-gold hover:text-white font-semibold text-sm flex items-center gap-1.5"
            >
              <span>View All Events Calendar</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-6">
            {initialEvents.slice(0, 3).map((event) => (
              <div 
                key={event.id} 
                className="bg-white/5 border border-white/10 rounded-xl p-6 hover:bg-white/10 transition-colors flex flex-col md:flex-row justify-between items-start md:items-center gap-6"
              >
                <div className="space-y-2 max-w-3xl">
                  <div className="flex flex-wrap items-center gap-3 text-xs">
                    <span className="text-gold font-bold uppercase">{event.category}</span>
                    <span className="text-slate-300">|</span>
                    <span className="text-slate-300">{event.date}</span>
                    <span className="text-slate-300">|</span>
                    <span className="text-slate-300">{event.venue}</span>
                  </div>
                  <h4 className="text-xl font-bold font-heading text-white">{event.title}</h4>
                  <p className="text-sm text-slate-300 leading-relaxed">{event.description}</p>
                </div>
                <button
                  id={`btn-reg-interest-${event.id}`}
                  onClick={() => onOpenRegisterEventModal(event)}
                  className="w-full md:w-auto px-5 py-2.5 bg-gold hover:bg-[#B37612] text-white text-sm font-bold rounded-md transition-colors text-center shrink-0"
                >
                  Register Interest
                </button>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* SECTION 6: ASSOCIATE PARTNERS (Logo Strip Marquee) */}
      <section className="py-12 bg-slate-50 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-xs text-slate-500 font-bold uppercase tracking-wider mb-8">
            Strategic Academic & Industry Partners Supporting AICAIML Guidelines
          </p>
          
          <div className="flex flex-wrap items-center justify-center gap-8 md:gap-16 opacity-75">
            {initialPartners.map((partner) => (
              <div key={partner.id} className="flex items-center gap-2 grayscale hover:grayscale-0 transition-all">
                <div className="bg-navy text-white text-xs font-mono font-black p-1.5 rounded">
                  {partner.logoPlaceholder}
                </div>
                <span className="text-sm font-semibold text-navy font-heading tracking-tight">
                  {partner.name}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 7: TESTIMONIALS (Interactive quote slider) */}
      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-xs uppercase text-corp-blue font-bold tracking-widest">Endorsements</span>
            <h3 className="text-3xl font-bold text-navy font-heading mt-1">Ecosystem Feedback</h3>
          </div>

          <div className="relative bg-pale-blue/30 border border-corp-blue/10 rounded-2xl p-8 md:p-12 shadow-sm">
            <div className="absolute top-6 left-6 text-corp-blue/10 font-serif text-7xl select-none">“</div>
            
            <div className="relative z-10 space-y-6">
              <p className="text-base md:text-lg text-slate-700 italic leading-relaxed">
                {initialTestimonials[testimonialIndex].quote}
              </p>
              
              <div className="flex items-center gap-4">
                <img 
                  src={initialTestimonials[testimonialIndex].avatarUrl} 
                  alt={initialTestimonials[testimonialIndex].name} 
                  className="w-12 h-12 rounded-full object-cover border-2 border-corp-blue/25"
                />
                <div>
                  <h4 className="text-navy font-bold text-sm font-heading">{initialTestimonials[testimonialIndex].name}</h4>
                  <p className="text-xs text-slate-500">{initialTestimonials[testimonialIndex].designation}</p>
                  <p className="text-xs font-semibold text-corp-blue">{initialTestimonials[testimonialIndex].organization}</p>
                </div>
              </div>
            </div>

            {/* Slider navigations */}
            <div className="flex gap-2 justify-end mt-4 md:mt-0">
              <button 
                onClick={handlePrevTestimonial}
                className="bg-white hover:bg-slate-50 border border-slate-200 p-2 rounded-full text-navy transition-colors shadow-sm"
              >
                <ChevronRight className="w-4 h-4 rotate-180" />
              </button>
              <button 
                onClick={handleNextTestimonial}
                className="bg-white hover:bg-slate-50 border border-slate-200 p-2 rounded-full text-navy transition-colors shadow-sm"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 8: ABOUT THE NETWORK FORUM (Summary block) */}
      <section className="py-16 bg-pale-blue border-t border-b border-corp-blue/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <span className="bg-corp-blue/10 text-corp-blue text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">National Platform</span>
              <h2 className="text-3xl font-extrabold text-navy font-heading">
                A Catalyst for Collaborative Technological Innovation
              </h2>
              <p className="text-slate-600 text-sm leading-relaxed">
                The AICAIML Network Forum operates as a unified professional body connecting academia, deep-tech startups, established industry partners, and policy advisories. Our core conviction is that artificial intelligence and machine learning serve as transforming engines for national progress.
              </p>
              <div className="space-y-3">
                {[
                  'Unified platform bridging academic research and industrial execution.',
                  'Formulates strategic advisory on ethical AI guidelines and bias testing.',
                  'Empowers students and faculty with practical edge-robotics toolkits.'
                ].map((point, index) => (
                  <div key={index} className="flex gap-2.5 items-start text-sm text-slate-700">
                    <Check className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                    <span>{point}</span>
                  </div>
                ))}
              </div>
              <button
                onClick={() => {
                  setCurrentPage('know-aicaiml');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="px-5 py-2.5 bg-navy hover:bg-corp-blue text-white font-semibold text-sm rounded-md transition-colors inline-flex items-center gap-2"
              >
                <span>Learn More about Know AICAIML</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
            
            {/* Visual Panel */}
            <div className="bg-white p-6 rounded-2xl shadow-xl border border-slate-100 space-y-6">
              <div className="flex items-center gap-3">
                <Brain className="w-8 h-8 text-corp-blue" />
                <h4 className="text-navy font-bold text-lg font-heading">AICAIML Operational Objectives</h4>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">
                By developing a cryptographically secure certification registry, localized agricultural IoT networks, and simulated robotics sandboxes, we establish robust pipelines supporting tomorrow’s technological needs.
              </p>
              
              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="bg-pale-blue/50 p-4 rounded-xl">
                  <span className="block text-2xl font-black text-navy">500+</span>
                  <span className="text-[10px] text-slate-500 font-bold uppercase">Clubs Launched</span>
                </div>
                <div className="bg-pale-blue/50 p-4 rounded-xl">
                  <span className="block text-2xl font-black text-navy">12+</span>
                  <span className="text-[10px] text-slate-500 font-bold uppercase">National Papers</span>
                </div>
                <div className="bg-pale-blue/50 p-4 rounded-xl">
                  <span className="block text-2xl font-black text-navy">50k+</span>
                  <span className="text-[10px] text-slate-500 font-bold uppercase">Students Reached</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 9: MEMBERSHIP CATEGORIES */}
      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-extrabold text-navy font-heading">Membership Categories</h2>
            <p className="text-slate-600 text-sm mt-2">Unlock institutional and professional benefits by selecting the relevant category</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { title: 'Student Forum', category: 'student', icon: GraduationCap, desc: 'For diploma, undergraduate, and postgraduate technical students looking for certifications, robotics clubs, and hackathon platforms.' },
              { title: 'MSME Network Forum', category: 'msme', icon: Building, desc: 'For proprietorships, partnerships, LLPs, and startups seek mentoring, academic tech-transfer, and networking scopes.' },
              { title: 'Corporate & Associate Partners', category: 'corporate', icon: Server, desc: 'For established hardware/software industries seeking university research alliances and pre-trained technical graduates.' },
              { title: 'School / College Institutional', category: 'school', icon: BookOpen, desc: 'For registered secondary schools and polytechnic colleges looking to establish AI & Robotics clubs on campus.' },
              { title: 'University Partnership', category: 'university', icon: Shield, desc: 'For state, central, and deemed universities seeking advanced Centers of Excellence (CoE) and faculty training plans.' },
              { title: 'Faculty & Researchers', category: 'student', icon: UserCheck, desc: 'For educators seeking UGC-aligned FDP certifications on Generative AI pipelines and academic research sandboxes.' }
            ].map((cat, idx) => {
              const IconComp = cat.icon;
              return (
                <div key={idx} className="bg-slate-50 hover:bg-slate-100/80 border border-slate-200/60 rounded-xl p-6 transition-all flex flex-col justify-between">
                  <div>
                    <div className="text-corp-blue bg-white p-3 rounded-lg w-fit mb-4 shadow-sm border border-slate-100">
                      <IconComp className="w-5 h-5" />
                    </div>
                    <h4 className="text-navy font-bold text-lg font-heading mb-2">{cat.title}</h4>
                    <p className="text-slate-600 text-sm leading-relaxed mb-6">{cat.desc}</p>
                  </div>
                  
                  {cat.category ? (
                    <button
                      id={`btn-apply-cat-${cat.category}`}
                      onClick={() => handleEnrollCategory(cat.category as any)}
                      className="w-full text-center py-2.5 bg-corp-blue hover:bg-navy text-white text-xs font-bold rounded-md transition-colors"
                    >
                      Apply for {cat.title}
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        setCurrentPage('membership');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="w-full text-center py-2.5 bg-slate-300 hover:bg-slate-400 text-slate-800 text-xs font-bold rounded-md transition-colors"
                    >
                      Learn More
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* SECTION 10: BENEFITS OF JOINING */}
      <section className="py-16 bg-gradient-to-br from-navy to-[#071F3F] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-6">
            <span className="text-xs uppercase text-gold font-bold tracking-widest">Growth Ecosystem</span>
            <h2 className="text-3xl font-bold font-heading text-white">Benefits of Joining the Council</h2>
            <p className="text-slate-300 text-sm leading-relaxed">
              Membership in AICAIML goes beyond standard credentials. It unlocks direct access to nationwide hackathons, academic funding structures, hardware simulation sandboxes, and executive policy frameworks designed to empower technical initiatives.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm pt-4">
              <div className="flex gap-2.5 items-center">
                <Check className="w-5 h-5 text-gold shrink-0" />
                <span>UGC and AICTE Aligned FDP Certifications</span>
              </div>
              <div className="flex gap-2.5 items-center">
                <Check className="w-5 h-5 text-gold shrink-0" />
                <span>Free Simulated Sandbox Research Access</span>
              </div>
              <div className="flex gap-2.5 items-center">
                <Check className="w-5 h-5 text-gold shrink-0" />
                <span>Placement & Internship Assistance Portals</span>
              </div>
              <div className="flex gap-2.5 items-center">
                <Check className="w-5 h-5 text-gold shrink-0" />
                <span>Industry-Academia Collaboration Scopes</span>
              </div>
            </div>
            <div className="pt-6">
              <button
                onClick={() => {
                  setCurrentPage('membership');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="px-6 py-3 bg-gold hover:bg-[#B37612] text-white text-sm font-semibold rounded-md shadow-md transition-all inline-flex items-center gap-2"
              >
                <span>Read Full Membership Benefits</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 11: NEWS & ANNOUNCEMENTS (CMS feed) */}
      <section className="py-16 md:py-24 bg-white border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end mb-12">
            <div>
              <span className="text-xs uppercase text-corp-blue font-bold tracking-widest">Media Desk</span>
              <h3 className="text-3xl font-extrabold text-navy font-heading mt-1">News & Announcements</h3>
              <p className="text-slate-500 text-sm mt-1">Latest council announcements, press statements, and deep tech policy changes.</p>
            </div>
            
            {/* Real CMS interaction toggle to showcase CMS edit capabilities! */}
            <button
              onClick={() => setShowAddNews(!showAddNews)}
              className="mt-4 sm:mt-0 px-4 py-2 border border-corp-blue text-corp-blue hover:bg-corp-blue hover:text-white text-xs font-semibold rounded-md transition-all flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              {showAddNews ? 'Close CMS Drawer' : 'Simulate CMS Publish'}
            </button>
          </div>

          {/* CMS news draft drawer */}
          {showAddNews && (
            <div className="bg-slate-50 border border-corp-blue/15 rounded-xl p-6 mb-8 max-w-2xl animate-slideup">
              <h4 className="font-bold text-navy font-heading mb-4 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-gold" />
                Simulate Direct News Publishing (CMS Feature)
              </h4>
              <form onSubmit={handlePublishNews} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">News Title</label>
                  <input 
                    type="text" 
                    required
                    placeholder="e.g., Council Approves Robotics Sandbox Grants"
                    className="w-full text-xs rounded border border-slate-300 p-2 focus:border-corp-blue focus:outline-none"
                    value={newNews.title}
                    onChange={(e) => setNewNews({ ...newNews, title: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Summary / Excerpt</label>
                  <textarea 
                    required
                    rows={3}
                    placeholder="Provide a detailed excerpt..."
                    className="w-full text-xs rounded border border-slate-300 p-2 focus:border-corp-blue focus:outline-none"
                    value={newNews.summary}
                    onChange={(e) => setNewNews({ ...newNews, summary: e.target.value })}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Category</label>
                    <select
                      className="w-full text-xs rounded border border-slate-300 p-2 focus:border-corp-blue focus:outline-none"
                      value={newNews.category}
                      onChange={(e) => setNewNews({ ...newNews, category: e.target.value as any })}
                    >
                      <option value="Announcement">Announcement</option>
                      <option value="Press Release">Press Release</option>
                      <option value="Industry News">Industry News</option>
                    </select>
                  </div>
                  <div className="flex items-end">
                    <button
                      type="submit"
                      disabled={isPublishing}
                      className="w-full px-4 py-2 bg-corp-blue text-white hover:bg-navy text-xs font-bold rounded shadow-md transition-colors flex items-center justify-center gap-1.5"
                    >
                      {isPublishing ? <Loader2 className="w-3 animate-spin" /> : 'Publish to Feed'}
                    </button>
                  </div>
                </div>
              </form>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {newsList.map((news) => (
              <div key={news.id} className="bg-slate-50 rounded-xl p-6 border border-slate-200/60 flex flex-col justify-between hover:shadow-md transition-all">
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-[10px] font-semibold text-slate-500">
                    <span className="text-accent-sky uppercase tracking-widest">{news.category}</span>
                    <span>{news.date}</span>
                  </div>
                  <h4 className="font-bold text-navy text-base font-heading line-clamp-2">{news.title}</h4>
                  <p className="text-xs text-slate-600 leading-relaxed line-clamp-3">{news.summary}</p>
                </div>
                <div className="pt-4 flex items-center justify-between text-xs font-bold border-t border-slate-200/60 mt-4">
                  <span className="text-slate-400">{news.readTime}</span>
                  <button onClick={() => {
                    alert(`Read detail: ${news.title}\n\nSummary: ${news.summary}`);
                  }} className="text-corp-blue hover:text-navy flex items-center gap-1">
                    <span>Read article</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 12: CONTACT INFORMATION & ENQUIRY FORM */}
      <section className="py-16 md:py-24 bg-pale-blue/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            
            {/* Contact Parameters block */}
            <div className="space-y-8">
              <div>
                <span className="text-xs uppercase text-corp-blue font-bold tracking-widest">Connect with Council</span>
                <h3 className="text-3xl font-extrabold text-navy font-heading mt-1">Contact Secretariat</h3>
                <p className="text-slate-600 text-sm mt-2">Get in touch for institutional registrations, sandbox setups, or general help.</p>
              </div>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-white p-3 rounded-xl shadow-sm text-corp-blue border border-slate-100">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-navy font-heading text-sm">National Headquarters</h4>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                      7th Floor, Innovation Tower, Block B, Institutional Area, Sector 62, Noida, Uttar Pradesh 201301
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-white p-3 rounded-xl shadow-sm text-corp-blue border border-slate-100">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-navy font-heading text-sm">Direct Phone Channels</h4>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                      +91 120 4882740<br />
                      +91 9810567211 (Secretariat Secretary Desk)
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-white p-3 rounded-xl shadow-sm text-corp-blue border border-slate-100">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-navy font-heading text-sm">Official Email Desk</h4>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                      <a href="mailto:info@aic-aiml.org" className="text-corp-blue hover:underline">info@aic-aiml.org</a><br />
                      <a href="mailto:support@aic-aiml.org" className="text-corp-blue hover:underline">support@aic-aiml.org</a>
                    </p>
                  </div>
                </div>
              </div>

              {/* Embedded Map Visual placeholder - stylized in corporate colors */}
              <div className="rounded-xl overflow-hidden shadow-md border border-slate-200">
                <div className="bg-navy px-4 py-2.5 text-white text-xs font-semibold flex items-center justify-between">
                  <span>Secretariat Map coordinates</span>
                  <span className="text-[10px] text-gold font-mono">28.6273° N, 77.3725° E</span>
                </div>
                <div className="bg-slate-200 h-48 flex items-center justify-center flex-col text-center p-6 relative">
                  {/* Styled mock map layout representing sector 62 */}
                  <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#0B2D5B_2px,transparent_2px)] [background-size:12px_12px] bg-slate-100"></div>
                  <div className="relative z-10 space-y-2">
                    <MapPin className="w-8 h-8 text-rose-600 mx-auto animate-bounce" />
                    <p className="text-xs font-bold text-navy font-heading">Noida Sector 62, Uttar Pradesh</p>
                    <p className="text-[10px] text-slate-500 max-w-xs mx-auto">Click map coordinates inside Google Maps to navigate directly to AICAIML Towers.</p>
                    <a 
                      href="https://maps.google.com/?q=Noida+Sector+62" 
                      target="_blank" 
                      rel="noreferrer"
                      className="inline-block mt-2 px-3 py-1 bg-navy text-white text-[10px] font-bold rounded hover:bg-corp-blue transition-colors"
                    >
                      Open in External Map
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* General Enquiry Form */}
            <div className="bg-white rounded-2xl shadow-xl border border-slate-100 p-6 md:p-8">
              <h4 className="font-bold text-navy font-heading text-lg mb-2">Council Enquiry Desk</h4>
              <p className="text-xs text-slate-500 mb-6">Have queries? Fill the quick form and we will revert back within 48 hours.</p>

              {enquirySuccess ? (
                <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-5 space-y-4 animate-slideup">
                  <div className="flex gap-2.5 items-start">
                    <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <h5 className="font-bold text-emerald-900 text-sm">Enquiry Registered Successfully</h5>
                      <p className="text-xs text-emerald-700 mt-1">Your query has been recorded. Reference ID: <strong>{enquirySuccess.referenceId}</strong></p>
                    </div>
                  </div>
                  <div className="bg-slate-900 text-slate-200 p-3 rounded font-mono text-[10px] leading-relaxed whitespace-pre-wrap">
                    {enquirySuccess.emailLog}
                  </div>
                  <button
                    onClick={() => setEnquirySuccess(null)}
                    className="w-full text-center py-2 bg-slate-100 text-slate-800 hover:bg-slate-200 text-xs font-bold rounded"
                  >
                    Submit Another Enquiry
                  </button>
                </div>
              ) : (
                <form onSubmit={handleEnquirySubmit} className="space-y-4">
                  {enquiryError && (
                    <div className="bg-rose-50 text-rose-800 p-3 rounded text-xs">
                      {enquiryError}
                    </div>
                  )}

                  {/* Anti-spam Honeypot field */}
                  <div className="hidden">
                    <label>Do not fill this if you are human</label>
                    <input 
                      type="text" 
                      value={honeypot} 
                      onChange={(e) => setHoneypot(e.target.value)} 
                      autoComplete="off"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Your Full Name *</label>
                      <input
                        type="text"
                        required
                        placeholder="John Doe"
                        className="w-full text-xs rounded border border-slate-300 p-2.5 focus:border-corp-blue focus:outline-none"
                        value={enquiryForm.name}
                        onChange={(e) => setEnquiryForm({ ...enquiryForm, name: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Email ID *</label>
                      <input
                        type="email"
                        required
                        placeholder="john@example.com"
                        className="w-full text-xs rounded border border-slate-300 p-2.5 focus:border-corp-blue focus:outline-none"
                        value={enquiryForm.email}
                        onChange={(e) => setEnquiryForm({ ...enquiryForm, email: e.target.value })}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Phone Number (Optional)</label>
                    <input
                      type="tel"
                      placeholder="e.g., +91 9999999999"
                      className="w-full text-xs rounded border border-slate-300 p-2.5 focus:border-corp-blue focus:outline-none"
                      value={enquiryForm.phone}
                      onChange={(e) => setEnquiryForm({ ...enquiryForm, phone: e.target.value })}
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Your Message / Enquiry Details *</label>
                    <textarea
                      required
                      rows={4}
                      placeholder="Specify your inquiry details..."
                      className="w-full text-xs rounded border border-slate-300 p-2.5 focus:border-corp-blue focus:outline-none"
                      value={enquiryForm.message}
                      onChange={(e) => setEnquiryForm({ ...enquiryForm, message: e.target.value })}
                    />
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={enquiryLoading}
                      id="btn-enquiry-submit"
                      className="w-full py-2.5 bg-corp-blue hover:bg-navy text-white text-xs font-bold rounded-md shadow-md transition-all flex items-center justify-center gap-1.5"
                    >
                      {enquiryLoading ? (
                        <>
                          <Loader2 className="w-4.5 h-4.5 animate-spin" />
                          Submitting...
                        </>
                      ) : (
                        'Submit Query'
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>

          </div>
        </div>
      </section>

    </div>
  );
}
