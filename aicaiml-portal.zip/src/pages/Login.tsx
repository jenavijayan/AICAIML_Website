import React, { useState } from 'react';
import { Shield, Lock, Eye, EyeOff, Loader2, KeyRound, Sparkles, AlertTriangle } from 'lucide-react';

export default function Login() {
  const [userId, setUserId] = useState('');
  const [category, setCategory] = useState('student');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setLoginError(null);

    // Simulated verification delay
    setTimeout(() => {
      setLoading(false);
      setLoginError(
        'Authorized Connection Established. However, the AICAIML member dashboard is currently locked. The full credentialed member portal launches in Phase 2.'
      );
    }, 1200);
  };

  return (
    <div id="login-portal-page" className="animate-slideup min-h-[70vh] flex items-center justify-center bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-white p-8 rounded-2xl shadow-xl border border-slate-100">
        
        {/* Logo and Headings */}
        <div className="text-center">
          <div className="mx-auto h-12 w-12 bg-navy rounded-xl flex items-center justify-center text-gold shadow-md">
            <Shield className="w-7 h-7" />
          </div>
          <h2 className="mt-4 text-2xl font-bold font-heading text-navy">
            Council Member Sign In
          </h2>
          <p className="mt-1 text-xs text-slate-500 max-w-sm mx-auto">
            Access secure simulation sandboxes, academic certifications, and council registries.
          </p>
        </div>

        {/* Phase 2 advisory note */}
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-3.5 flex gap-2 text-xs text-amber-800 leading-relaxed">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold">Phase 1 Status Notification:</span>
            <p className="mt-0.5">The unified member portal is presently sandboxed. Active user dashboards and credential accesses are slated for general release in Phase 2.</p>
          </div>
        </div>

        {/* Login Form */}
        <form onSubmit={handleLogin} className="space-y-4">
          {loginError && (
            <div className="bg-rose-50 border border-rose-200 text-rose-800 rounded-lg p-4 text-xs leading-normal">
              {loginError}
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              User ID / Membership No. *
            </label>
            <input
              type="text"
              required
              placeholder="e.g., AIC-STU-123456"
              className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm focus:border-corp-blue focus:outline-none"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Member Category *
            </label>
            <select
              className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm focus:border-corp-blue focus:outline-none bg-white"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option value="student">Student Forum</option>
              <option value="msme">MSME Network Forum</option>
              <option value="corporate">Corporate & Associate Partner</option>
              <option value="school">School / College Institutional</option>
              <option value="university">University Partnership</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Password *
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                placeholder="••••••••"
                className="w-full rounded-md border border-slate-300 pl-3 pr-10 py-2 text-sm focus:border-corp-blue focus:outline-none"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 transition-colors"
              >
                {showPassword ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs pt-1">
            <label className="flex items-center gap-1.5 cursor-pointer text-slate-600">
              <input type="checkbox" className="rounded text-corp-blue focus:ring-corp-blue" />
              <span>Remember me</span>
            </label>
            <button
              type="button"
              onClick={() => alert("Forgot password? Under standard Council bylaws, password reset coordinates must be submitted physically by accredited coordinators. Contact support@aic-aiml.org for manual reset instructions.")}
              className="text-accent-sky hover:text-corp-blue font-semibold"
            >
              Forgot Password?
            </button>
          </div>

          <button
            type="submit"
            disabled={loading}
            id="btn-login-submit"
            className="w-full py-2.5 bg-corp-blue hover:bg-navy text-white text-sm font-semibold rounded-md shadow-md transition-all flex items-center justify-center gap-1.5 mt-4"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Authorizing Security Token...
              </>
            ) : (
              'Sign In'
            )}
          </button>
        </form>

        <div className="text-center pt-4 border-t border-slate-100 text-xs text-slate-500">
          Not yet a member?{' '}
          <button
            onClick={() => {
              // Hack to trigger membership tab selection page on App
              window.location.hash = 'membership';
              window.location.reload();
            }}
            className="text-accent-sky hover:text-corp-blue font-semibold underline"
          >
            Register Membership
          </button>
        </div>

      </div>
    </div>
  );
}
