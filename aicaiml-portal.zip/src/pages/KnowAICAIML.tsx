import React from 'react';
import { Target, Compass, BookOpen, Shield, ShieldCheck, Heart, Award, Sparkles } from 'lucide-react';

export default function KnowAICAIML() {
  return (
    <div id="know-aicaiml-page" className="animate-slideup bg-white py-12 md:py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        {/* Page Top Title */}
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-pale-blue text-corp-blue rounded-full text-xs font-bold uppercase tracking-wider">
            <Shield className="w-4 h-4 text-gold" />
            <span>Executive Identity Statement</span>
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-navy font-heading">
            About AICAIML
          </h1>
          <p className="text-slate-500 text-base max-w-xl mx-auto">
            Establishing India as a premier deep tech nexus through research-backed curriculum standards and secure digital integration frameworks.
          </p>
        </div>

        {/* 1. VISION SECTION */}
        <div className="bg-pale-blue/40 border border-corp-blue/10 rounded-2xl p-6 md:p-10 space-y-4">
          <div className="flex items-center gap-3">
            <div className="bg-corp-blue text-white p-2.5 rounded-lg">
              <Compass className="w-6 h-6" />
            </div>
            <h2 className="text-2xl font-bold text-navy font-heading">Our Vision</h2>
          </div>
          <p className="text-slate-700 text-base md:text-lg leading-relaxed font-medium pl-1">
            "To establish India as a global leader in Artificial Intelligence, Machine Learning, and Robotics by fostering innovation, research, skill development, and collaborative partnerships among students, educators, researchers, industries, startups, and institutions for sustainable national and global progress."
          </p>
        </div>

        {/* 2. MISSION SECTION */}
        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <div className="bg-corp-blue text-white p-2.5 rounded-lg">
              <Target className="w-6 h-6" />
            </div>
            <h2 className="text-2xl font-bold text-navy font-heading">Our Mission</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-1">
            {[
              { text: 'Education, Training & Certification Excellence: Setting high standards in AI, ML, and Robotics training with curriculum integration and cryptographically secure digital credentials.' },
              { text: 'Nationwide Network Building: Connecting academia, research laboratories, MSMEs, deep-tech startups, and governmental bodies.' },
              { text: 'Research & Innovation: Accelerating experimental projects and tech transfer via distributed physical sandbox labs and simulation environments.' },
              { text: 'Conferences, Hackathons & FDPs: Direct execution of academic congresses, hardware design hackathons, and AICTE-aligned teacher training.' },
              { text: 'Robotics Clubs & Centres of Excellence: Providing funding and physical parts-kits to launch innovative on-campus clubs.' },
              { text: 'Technology Transfer & Collaboration: Empowering MSMEs with advanced university research, algorithms, and industrial methodologies.' },
              { text: 'Ethical & Trustworthy AI Adoption: Formulating auditing advisories and bias evaluations for healthcare, finance, and logistics algorithms.' },
              { text: 'Youth Empowerment: Equipping graduates in tier-2 and tier-3 locations with specialized practical credentials for the modern digital economy.' }
            ].map((mission, idx) => (
              <div key={idx} className="bg-slate-50 border border-slate-100 rounded-lg p-5 hover:bg-slate-100/50 transition-colors flex gap-3">
                <ShieldCheck className="w-5 h-5 text-gold shrink-0 mt-0.5" />
                <p className="text-slate-700 text-sm leading-relaxed">{mission.text}</p>
              </div>
            ))}
          </div>
        </div>

        {/* 3. ABOUT AICAIML NARRATIVE */}
        <div className="space-y-6 border-t border-slate-100 pt-12">
          <h2 className="text-2xl font-bold text-navy font-heading flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-gold" />
            The AICAIML Council Core Philosophy
          </h2>
          
          <div className="text-slate-700 text-sm md:text-base space-y-5 leading-relaxed pl-1 text-justify">
            <p>
              The All India Council for Artificial Intelligence and Machine Learning (AICAIML) stands as a prominent national professional council connecting academia, industry, government, startups, and technology professionals under a single-view advancement framework. We believe that Artificial Intelligence is a transformative, fundamental force altering human potential, and the council acts as an essential catalyst for global, multi-stakeholder collaboration.
            </p>
            <p>
              Through our core initiatives—including prestigious national academic conferences, industry-endorsed professional certifications, intensive Faculty Development Programs (FDPs), campus-based innovation sandboxes, and robotics competitions—we establish a strong bridge between pure theoretical knowledge and applied technical competence. We support technology incubation, academic research collaborations, and policy dialogues with regulatory boards to ensure national alignment with emerging standards.
            </p>
            <p>
              AICAIML remains deeply committed to promoting ethical, trustworthy, and human-centered AI. We believe that advanced computational models should align with democratic values, safeguard individual privacy, and mitigate systemic biases. By setting strict technological benchmarks and working closely with local stakeholders, we establish guidelines that ensure deep-tech assets are deployed safely.
            </p>
            <p className="font-semibold text-corp-blue text-base border-l-4 border-gold pl-4 italic">
              "We don't simply prepare people for the future—we help create it."
            </p>
          </div>
        </div>

        {/* 4. OUR PURPOSE STATEMENT */}
        <div className="space-y-4 border-t border-slate-100 pt-12">
          <h2 className="text-2xl font-bold text-navy font-heading">Our Purpose</h2>
          <p className="text-slate-600 text-sm md:text-base leading-relaxed pl-1 text-justify">
            To serve as a standard-setting registry and active research-funding ecosystem. Our primary purpose is to elevate academic competencies, support entrepreneurship, facilitate technology transfers, and ensure that Indian technical professionals possess the specialized skills required to lead national deep-tech development.
          </p>
        </div>

        {/* 5. OUR COMMITMENT */}
        <div className="space-y-6 border-t border-slate-100 pt-12">
          <h2 className="text-2xl font-bold text-navy font-heading flex items-center gap-2">
            <Heart className="w-5 h-5 text-rose-500 shrink-0" />
            Our Commitments
          </h2>
          
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4 pl-1 text-sm text-slate-700">
            {[
              'Advance Knowledge and Technological Excellence across computational sciences.',
              'Build strong Academia-Industry-Government connections for rapid tech deployment.',
              'Promote Ethical AI frameworks and algorithmic accountability protocols.',
              'Inspire Innovation and Entrepreneurship among campus engineering graduates.',
              'Empower Future Technology Leaders with practical, verified certifications.',
              'Create Global Collaboration Opportunities in autonomous robotics and edge-ML research.'
            ].map((commitment, index) => (
              <li key={index} className="flex gap-3 items-start bg-slate-50 border border-slate-100 rounded-lg p-4">
                <div className="bg-corp-blue/10 text-corp-blue p-1 rounded-md shrink-0">
                  <CheckCircleIcon className="w-4 h-4" />
                </div>
                <span>{commitment}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* 6. CLOSING TAGLINE */}
        <div className="border-t border-slate-100 pt-12 text-center space-y-2">
          <span className="text-xs uppercase text-slate-400 font-bold tracking-widest">AICAIML Slogan</span>
          <p className="text-2xl sm:text-3xl font-black font-heading tracking-widest text-corp-blue">
            INNOVATE. COLLABORATE. TRANSFORM.
          </p>
        </div>

      </div>
    </div>
  );
}

// Small icon helper
function CheckCircleIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <path d="m9 12 2 2 4-4" />
    </svg>
  );
}
