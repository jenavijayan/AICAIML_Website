import { useState, useEffect } from 'react';
import { Menu, X, Shield, ChevronRight, Award, DollarSign } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HeaderProps {
  currentPage: string;
  setCurrentPage: (page: string) => void;
  onOpenDonationModal: () => void;
}

export default function Header({ currentPage, setCurrentPage, onOpenDonationModal }: HeaderProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'know-aicaiml', label: 'Know AICAIML' },
    { id: 'learners', label: 'Learners, Associates and Members' },
    { id: 'events-projects', label: 'Events & Projects' },
    { id: 'membership', label: 'Membership' },
    { id: 'login', label: 'Login' }
  ];

  const handleNavClick = (pageId: string) => {
    setCurrentPage(pageId);
    setIsMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header
      id="global-header"
      className={`sticky top-0 z-50 w-full transition-all duration-300 ${
        isScrolled 
          ? 'bg-navy/95 backdrop-blur-md py-3 shadow-lg' 
          : 'bg-navy py-4 shadow-md'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          
          {/* Logo Brand Section */}
          <div 
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="bg-white/10 p-2 rounded-lg group-hover:bg-accent-sky/20 transition-colors">
              <Shield className="w-8 h-8 text-gold" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-bold tracking-wider text-white font-heading">
                  AICAIML
                </span>
                <span className="inline-flex items-center rounded-full bg-gold/20 px-1.5 py-0.5 text-xs font-medium text-gold ring-1 ring-inset ring-gold/30">
                  Govt Regd
                </span>
              </div>
              <p className="hidden md:block text-[10px] text-pale-blue tracking-wide font-sans uppercase">
                All India Council for Artificial Intelligence & Machine Learning
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navItems.map((item) => {
              const isActive = currentPage === item.id || 
                (item.id === 'membership' && currentPage.startsWith('membership-form'));
              return (
                <button
                  key={item.id}
                  id={`nav-link-${item.id}`}
                  onClick={() => handleNavClick(item.id)}
                  className={`px-3 py-2 text-sm font-medium rounded-md transition-all duration-150 ${
                    isActive
                      ? 'text-gold bg-white/10'
                      : 'text-white hover:text-accent-sky hover:bg-white/5'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Call-to-Action Buttons */}
          <div className="hidden sm:flex items-center gap-3">
            <button
              id="header-btn-donation"
              onClick={onOpenDonationModal}
              className="flex items-center gap-1.5 px-4 py-2 border-2 border-gold/40 text-gold hover:border-gold hover:bg-gold/10 text-sm font-semibold rounded-md transition-all"
            >
              <DollarSign className="w-4 h-4" />
              Donation
            </button>
            <button
              id="header-btn-join"
              onClick={() => handleNavClick('membership')}
              className="flex items-center gap-1.5 px-4 py-2 bg-gold hover:bg-[#B37612] text-white text-sm font-semibold rounded-md shadow-md hover:shadow-lg transition-all"
            >
              <Award className="w-4 h-4" />
              Join Network
            </button>
          </div>

          {/* Mobile Hamburguer Toggle Button */}
          <div className="flex lg:hidden">
            <button
              id="mobile-menu-toggle"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-white hover:text-accent-sky hover:bg-white/10 transition-colors focus:outline-none"
              aria-expanded="false"
            >
              <span className="sr-only">Open main menu</span>
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-navy border-t border-white/10 overflow-hidden"
          >
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              {navItems.map((item) => {
                const isActive = currentPage === item.id || 
                  (item.id === 'membership' && currentPage.startsWith('membership-form'));
                return (
                  <button
                    key={item.id}
                    id={`mobile-nav-link-${item.id}`}
                    onClick={() => handleNavClick(item.id)}
                    className={`flex w-full items-center justify-between px-3 py-3 rounded-md text-base font-medium transition-colors ${
                      isActive
                        ? 'text-gold bg-white/10'
                        : 'text-white hover:text-accent-sky hover:bg-white/5'
                    }`}
                  >
                    <span>{item.label}</span>
                    <ChevronRight className="w-4 h-4 text-white/30" />
                  </button>
                );
              })}

              <div className="grid grid-cols-2 gap-2 pt-4 px-3 border-t border-white/10">
                <button
                  id="mobile-btn-donation"
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onOpenDonationModal();
                  }}
                  className="flex items-center justify-center gap-1 px-4 py-2 border border-gold text-gold rounded-md text-sm font-semibold hover:bg-gold/10 transition-all"
                >
                  <DollarSign className="w-4 h-4" />
                  Donation
                </button>
                <button
                  id="mobile-btn-join"
                  onClick={() => handleNavClick('membership')}
                  className="flex items-center justify-center gap-1 px-4 py-2 bg-gold text-white rounded-md text-sm font-semibold hover:bg-[#B37612] transition-all"
                >
                  <Award className="w-4 h-4" />
                  Join Network
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
