import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Shield, X, CreditCard, Heart, CheckCircle, Mail, AlertCircle, 
  ArrowRight, Info, Copy, Calendar, MapPin, DollarSign, Award, Clock, BookOpen
} from 'lucide-react';

// Import components and pages
import Header from './components/Header';
import Footer from './components/Footer';
import CookieConsent from './components/CookieConsent';
import MembershipForms from './components/MembershipForms';

import Home from './pages/Home';
import KnowAICAIML from './pages/KnowAICAIML';
import Learners from './pages/Learners';
import EventsProjects from './pages/EventsProjects';
import Benefits from './pages/Benefits';
import Login from './pages/Login';
import Legal from './pages/Legal';

import { UpcomingEvent } from './cmsData';

export default function App() {
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [selectedCategory, setSelectedCategory] = useState<'student' | 'msme' | 'corporate' | 'school' | 'university' | null>(null);

  // Modal States
  const [isDonationOpen, setIsDonationOpen] = useState(false);
  const [activeRegEvent, setActiveRegEvent] = useState<UpcomingEvent | null>(null);

  // Form registration states (inside registration modal)
  const [regForm, setRegForm] = useState({ name: '', email: '', phone: '', organization: '', designation: '' });
  const [regHoneypot, setRegHoneypot] = useState('');
  const [regLoading, setRegLoading] = useState(false);
  const [regSuccess, setRegSuccess] = useState<any | null>(null);
  const [regError, setRegError] = useState<string | null>(null);

  // Donation interactive state
  const [donationAmount, setDonationAmount] = useState('5000');
  const [customDonation, setCustomDonation] = useState('');
  const [donationHoneypot, setDonationHoneypot] = useState('');
  const [donationSuccess, setDonationSuccess] = useState<any | null>(null);
  const [donationForm, setDonationForm] = useState({ name: '', email: '', panNo: '' });

  // Read hash fragment for back-links from components
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '');
      if (hash && ['home', 'know-aicaiml', 'learners', 'events-projects', 'membership', 'login', 'privacy', 'terms'].includes(hash)) {
        setCurrentPage(hash);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    handleHashChange();
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Event Register submit
  const handleEventRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeRegEvent) return;
    setRegLoading(true);
    setRegError(null);
    setRegSuccess(null);

    try {
      const response = await fetch('/api/events/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          eventId: activeRegEvent.id,
          eventTitle: activeRegEvent.title,
          ...regForm,
          honeypot: regHoneypot
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to submit event registration.');
      }

      setRegSuccess(data);
      setRegForm({ name: '', email: '', phone: '', organization: '', designation: '' });
    } catch (err: any) {
      setRegError(err.message || 'An unexpected server error occurred.');
    } finally {
      setRegLoading(false);
    }
  };

  // Donation submit
  const handleDonationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (donationHoneypot) return; // Silent spam fail

    const amount = customDonation || donationAmount;
    const refNo = 'AIC-DON-' + Math.floor(100000 + Math.random() * 900000);

    const log = `
      Subject: [AICAIML] Donation Receipt Received - Ref: ${refNo}
      To: ${donationForm.email}
      
      Dear ${donationForm.name},
      
      We acknowledge receipt of your donation request to the All India Council for Artificial Intelligence and Machine Learning.
      
      DONATION RECEIPT SUMMARY:
      - Receipt Reference No: ${refNo}
      - Contributor: ${donationForm.name}
      - Pledged Amount: INR ${amount}
      - PAN Card Number: ${donationForm.panNo || 'Not provided'}
      - Council Tax Exemption Code: Sec 80G compliant
      
      Please complete the bank transfer (NEFT/RTGS) to the official Council bank account below to lock in this receipt.
      
      COUNCIL BANK DETAILS:
      - Account Name: All India Council for Artificial Intelligence and Machine Learning
      - Bank Name: State Bank of India
      - Branch: Noida Sector 62 Commercial Branch
      - Account No: 40991203456
      - IFSC Code: SBIN0001029
      
      Thank you for supporting deep-tech research and educational sandboxes in India.
      
      Sincerely,
      Treasury Desk, AICAIML Council
    `;

    setDonationSuccess({
      refNo,
      amount,
      log
    });
  };

  const handleCopyBank = (text: string) => {
    navigator.clipboard.writeText(text);
    alert(`Copied to clipboard: ${text}`);
  };

  return (
    <div id="aicaiml-root" className="min-h-screen bg-white flex flex-col font-sans">
      
      {/* GLOBAL HEADER */}
      <Header 
        currentPage={currentPage} 
        setCurrentPage={setCurrentPage} 
        onOpenDonationModal={() => {
          setDonationSuccess(null);
          setIsDonationOpen(true);
        }}
      />

      {/* RENDER ACTIVE PAGE */}
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage + (selectedCategory || '')}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
          >
            {currentPage === 'home' && (
              <Home 
                setCurrentPage={setCurrentPage} 
                setSelectedCategory={setSelectedCategory}
                onOpenRegisterEventModal={(event) => {
                  setRegSuccess(null);
                  setRegError(null);
                  setActiveRegEvent(event);
                }}
                onOpenDonationModal={() => {
                  setDonationSuccess(null);
                  setIsDonationOpen(true);
                }}
              />
            )}

            {currentPage === 'know-aicaiml' && <KnowAICAIML />}

            {currentPage === 'learners' && <Learners />}

            {currentPage === 'events-projects' && (
              <EventsProjects 
                onOpenRegisterEventModal={(event) => {
                  setRegSuccess(null);
                  setRegError(null);
                  setActiveRegEvent(event);
                }}
              />
            )}

            {currentPage === 'membership' && (
              <div className="py-12 md:py-20 bg-slate-50 min-h-[80vh]">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  {selectedCategory ? (
                    <MembershipForms 
                      category={selectedCategory} 
                      onBack={() => setSelectedCategory(null)} 
                    />
                  ) : (
                    <div className="space-y-12">
                      <div className="text-center max-w-2xl mx-auto space-y-3">
                        <span className="text-xs uppercase text-corp-blue font-bold tracking-widest">Enrollment Registry</span>
                        <h1 className="text-3xl font-bold text-navy font-heading">Choose Membership Category</h1>
                        <p className="text-slate-500 text-sm">
                          Select the appropriate membership structure below to launch the dedicated multi-field application registry.
                        </p>
                      </div>

                      {/* 5 illustrated category cards */}
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
                        {[
                          { id: 'student' as const, title: 'Student', icon: Award, color: 'border-emerald-200 bg-emerald-50/40 text-emerald-700', desc: 'Diploma, Undergraduate and Graduate enrollments for certification pipelines.' },
                          { id: 'msme' as const, title: 'MSME', icon: Shield, color: 'border-blue-200 bg-blue-50/40 text-blue-700', desc: 'Proprietorships, partnerships, LLPs seeking tech-transfer models.' },
                          { id: 'corporate' as const, title: 'Associate Partner', icon: CreditCard, color: 'border-purple-200 bg-purple-50/40 text-purple-700', desc: 'Established companies collaborating on CSR and FDP setups.' },
                          { id: 'school' as const, title: 'School / College', icon: BookOpen, color: 'border-amber-200 bg-amber-50/40 text-amber-700', desc: 'Secondary schools and polytechnics creating campus AI & Robotics clubs.' },
                          { id: 'university' as const, title: 'University', icon: Award, color: 'border-rose-200 bg-rose-50/40 text-rose-700', desc: 'Central, state and deemed universities launching advanced CoEs.' }
                        ].map((cat) => {
                          const IconComp = cat.icon;
                          return (
                            <div 
                              key={cat.id} 
                              onClick={() => setSelectedCategory(cat.id)}
                              className={`rounded-2xl border p-5 flex flex-col justify-between hover:shadow-lg transition-all cursor-pointer bg-white border-slate-200/60 hover:border-corp-blue group`}
                            >
                              <div className="space-y-4">
                                <div className={`p-3 rounded-xl w-fit ${cat.color} group-hover:scale-105 transition-transform`}>
                                  <IconComp className="w-6 h-6" />
                                </div>
                                <h3 className="font-bold text-navy text-base font-heading group-hover:text-corp-blue transition-colors">{cat.title}</h3>
                                <p className="text-slate-500 text-xs leading-relaxed">{cat.desc}</p>
                              </div>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedCategory(cat.id);
                                }}
                                className="mt-6 w-full text-center py-2 bg-navy text-white hover:bg-corp-blue text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1"
                              >
                                <span>Register Form</span>
                                <ArrowRight className="w-3 h-3" />
                              </button>
                            </div>
                          );
                        })}
                      </div>

                      {/* Redirect to Benefits Page */}
                      <div className="bg-white border rounded-xl p-6 md:p-8 flex flex-col md:flex-row justify-between items-center gap-6 max-w-4xl mx-auto shadow-sm">
                        <div className="space-y-1 text-center md:text-left">
                          <h4 className="font-bold text-navy font-heading text-lg">Unsure about membership privileges?</h4>
                          <p className="text-slate-500 text-xs">Read the detailed advantages and bullets tailored for each technical partner segment.</p>
                        </div>
                        
                        <button
                          onClick={() => {
                            // Inject fake state to render Benefits inside dynamic view
                            setCurrentPage('benefits-view');
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                          }}
                          className="px-5 py-2.5 bg-corp-blue hover:bg-navy text-white text-xs font-bold rounded-md transition-all inline-flex items-center gap-1.5 shrink-0"
                        >
                          <span>Explore Full Benefits Grid</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>

                    </div>
                  )}
                </div>
              </div>
            )}

            {currentPage === 'benefits-view' && (
              <Benefits onJoinClick={(cat) => {
                setSelectedCategory(cat);
                setCurrentPage('membership');
              }} />
            )}

            {currentPage === 'login' && <Login />}

            {currentPage === 'privacy' && <Legal initialSection="privacy" />}
            {currentPage === 'terms' && <Legal initialSection="terms" />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* GLOBAL FOOTER */}
      <Footer setCurrentPage={setCurrentPage} />

      {/* COOKIE CONSENT BANNER */}
      <CookieConsent onOpenPrivacyPage={() => setCurrentPage('privacy')} />

      {/* ------------------------------------------------------------- */}
      {/* MODAL 1: EVENT INTEREST REGISTRATION MODAL */}
      {/* ------------------------------------------------------------- */}
      <AnimatePresence>
        {activeRegEvent && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveRegEvent(null)}
              className="absolute inset-0 bg-navy/60 backdrop-blur-sm"
            />
            
            {/* Modal Box */}
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl shadow-2xl border border-slate-100 max-w-lg w-full overflow-hidden relative z-10 max-h-[90vh] flex flex-col"
            >
              {/* Header */}
              <div className="bg-navy p-5 text-white flex justify-between items-center">
                <div>
                  <span className="text-[10px] uppercase text-gold font-bold tracking-wider">AICAIML Registration Registry</span>
                  <h4 className="font-bold text-base font-heading line-clamp-1">{activeRegEvent.title}</h4>
                </div>
                <button 
                  onClick={() => setActiveRegEvent(null)}
                  className="text-slate-300 hover:text-white hover:bg-white/10 p-1.5 rounded-md transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Form body */}
              <div className="p-6 overflow-y-auto space-y-4">
                
                {regSuccess ? (
                  <div className="space-y-4 animate-slideup">
                    <div className="flex gap-2.5 items-start">
                      <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <h5 className="font-bold text-emerald-900 text-sm">Interest Registered!</h5>
                        <p className="text-xs text-emerald-700 mt-1">
                          You have successfully registered interest. Registration Ticket: <strong>{regSuccess.registrationId}</strong>
                        </p>
                      </div>
                    </div>
                    
                    <div className="bg-slate-900 text-slate-200 p-3 rounded font-mono text-[10px] leading-relaxed whitespace-pre-wrap max-h-48 overflow-y-auto">
                      {regSuccess.emailLog}
                    </div>

                    <button
                      onClick={() => setActiveRegEvent(null)}
                      className="w-full text-center py-2.5 bg-navy hover:bg-corp-blue text-white text-xs font-bold rounded"
                    >
                      Close Modal
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleEventRegisterSubmit} className="space-y-4">
                    {regError && (
                      <div className="bg-rose-50 text-rose-800 p-3 rounded text-xs">
                        {regError}
                      </div>
                    )}

                    {/* Honeypot anti-spam check */}
                    <div className="hidden">
                      <label>Do not fill if human</label>
                      <input 
                        type="text" 
                        value={regHoneypot} 
                        onChange={(e) => setRegHoneypot(e.target.value)} 
                        autoComplete="off"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-xs">
                      <div>
                        <span className="block text-slate-400">Event Date</span>
                        <span className="font-semibold text-navy flex items-center gap-1 mt-0.5"><Calendar className="w-3.5 h-3.5 text-gold" /> {activeRegEvent.date}</span>
                      </div>
                      <div>
                        <span className="block text-slate-400">Venue / Access</span>
                        <span className="font-semibold text-navy flex items-center gap-1 mt-0.5"><MapPin className="w-3.5 h-3.5 text-gold" /> {activeRegEvent.venue}</span>
                      </div>
                    </div>

                    <div className="border-t border-slate-100 pt-4 space-y-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">Your Full Name *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g., Anjali Sharma"
                          className="w-full text-xs rounded border border-slate-300 p-2.5 focus:border-corp-blue focus:outline-none"
                          value={regForm.name}
                          onChange={(e) => setRegForm({ ...regForm, name: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">Your Email ID *</label>
                        <input
                          type="email"
                          required
                          placeholder="anjali@domain.com"
                          className="w-full text-xs rounded border border-slate-300 p-2.5 focus:border-corp-blue focus:outline-none"
                          value={regForm.email}
                          onChange={(e) => setRegForm({ ...regForm, email: e.target.value })}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">Organization / Inst Name</label>
                          <input
                            type="text"
                            placeholder="e.g., IIT Delhi"
                            className="w-full text-xs rounded border border-slate-300 p-2.5 focus:border-corp-blue focus:outline-none"
                            value={regForm.organization}
                            onChange={(e) => setRegForm({ ...regForm, organization: e.target.value })}
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">Designation</label>
                          <input
                            type="text"
                            placeholder="e.g., Student, Lecturer"
                            className="w-full text-xs rounded border border-slate-300 p-2.5 focus:border-corp-blue focus:outline-none"
                            value={regForm.designation}
                            onChange={(e) => setRegForm({ ...regForm, designation: e.target.value })}
                          />
                        </div>
                      </div>
                    </div>

                    <p className="text-[10px] text-slate-400">
                      * Registering interest alerts the events coordination desk. Seat allocations and virtual links will be emailed 24 hours prior.
                    </p>

                    <div className="pt-2 flex justify-end gap-2.5">
                      <button
                        type="button"
                        onClick={() => setActiveRegEvent(null)}
                        className="px-4 py-2 border border-slate-300 rounded text-slate-600 text-xs hover:bg-slate-50 font-bold"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={regLoading}
                        className="px-5 py-2.5 bg-gold text-white hover:bg-[#B37612] text-xs font-bold rounded flex items-center justify-center gap-1 min-w-[120px]"
                      >
                        {regLoading ? 'Processing...' : 'Register Ticket'}
                      </button>
                    </div>
                  </form>
                )}

              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ------------------------------------------------------------- */}
      {/* MODAL 2: DONATION COMPLIANCE & BANK DETAILS MODAL */}
      {/* ------------------------------------------------------------- */}
      <AnimatePresence>
        {isDonationOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsDonationOpen(false)}
              className="absolute inset-0 bg-navy/60 backdrop-blur-sm"
            />

            {/* Modal Box */}
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl shadow-2xl border border-slate-100 max-w-lg w-full overflow-hidden relative z-10 max-h-[90vh] flex flex-col"
            >
              {/* Header */}
              <div className="bg-navy p-5 text-white flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Heart className="w-5 h-5 text-gold fill-current" />
                  <h4 className="font-bold text-base font-heading">Support AICAIML Research (Donations)</h4>
                </div>
                <button 
                  onClick={() => setIsDonationOpen(false)}
                  className="text-slate-300 hover:text-white hover:bg-white/10 p-1.5 rounded-md transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Form body */}
              <div className="p-6 overflow-y-auto space-y-5">
                
                {donationSuccess ? (
                  <div className="space-y-4 animate-slideup">
                    <div className="flex gap-2.5 items-start bg-emerald-50 border border-emerald-200 rounded-xl p-4">
                      <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <h5 className="font-bold text-emerald-900 text-sm">Donation Registered</h5>
                        <p className="text-xs text-emerald-700 mt-1">
                          A pledge for <strong>INR {donationSuccess.amount}</strong> has been registered. Reference: <strong>{donationSuccess.refNo}</strong>
                        </p>
                      </div>
                    </div>

                    <div className="border border-slate-200 rounded-lg p-4 bg-slate-50 space-y-3">
                      <span className="text-[10px] text-slate-500 font-bold uppercase block">COUNCIL BANKING COORDINATES (NEFT/RTGS)</span>
                      
                      <div className="grid grid-cols-2 gap-3 text-xs font-mono text-slate-700">
                        <div>
                          <span className="text-[9px] text-slate-400 block">Bank Name</span>
                          <span className="font-bold text-navy">State Bank of India</span>
                        </div>
                        <div>
                          <span className="text-[9px] text-slate-400 block">Branch Name</span>
                          <span className="font-bold text-navy">Noida Sector 62 Branch</span>
                        </div>
                        <div>
                          <span className="text-[9px] text-slate-400 block">Account No.</span>
                          <span className="font-bold text-navy select-all flex items-center gap-1">
                            40991203456
                            <button onClick={() => handleCopyBank('40991203456')} className="text-corp-blue hover:text-navy shrink-0"><Copy className="w-3 h-3" /></button>
                          </span>
                        </div>
                        <div>
                          <span className="text-[9px] text-slate-400 block">IFSC Code</span>
                          <span className="font-bold text-navy select-all flex items-center gap-1">
                            SBIN0001029
                            <button onClick={() => handleCopyBank('SBIN0001029')} className="text-corp-blue hover:text-navy shrink-0"><Copy className="w-3 h-3" /></button>
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-slate-900 text-slate-200 p-3 rounded font-mono text-[10px] leading-relaxed whitespace-pre-wrap max-h-40 overflow-y-auto">
                      {donationSuccess.log}
                    </div>

                    <button
                      onClick={() => setIsDonationOpen(false)}
                      className="w-full text-center py-2.5 bg-navy hover:bg-corp-blue text-white text-xs font-bold rounded"
                    >
                      Close Receipt
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleDonationSubmit} className="space-y-4">
                    
                    {/* Honeypot spam check */}
                    <div className="hidden">
                      <input 
                        type="text" 
                        value={donationHoneypot} 
                        onChange={(e) => setDonationHoneypot(e.target.value)} 
                        autoComplete="off"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">Select Pledged Amount (INR)</label>
                      <div className="grid grid-cols-4 gap-2">
                        {['1000', '5000', '10000', '25000'].map((amt) => (
                          <button
                            key={amt}
                            type="button"
                            onClick={() => {
                              setDonationAmount(amt);
                              setCustomDonation('');
                            }}
                            className={`py-2 text-xs font-bold border rounded-lg transition-all ${
                              donationAmount === amt && !customDonation
                                ? 'bg-corp-blue border-corp-blue text-white shadow-sm'
                                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                            }`}
                          >
                            ₹{Number(amt).toLocaleString('en-IN')}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Or Enter Custom Amount (INR)</label>
                      <input
                        type="number"
                        placeholder="e.g., 50000"
                        className="w-full text-xs rounded border border-slate-300 p-2.5 focus:border-corp-blue focus:outline-none"
                        value={customDonation}
                        onChange={(e) => {
                          setCustomDonation(e.target.value);
                          setDonationAmount('');
                        }}
                      />
                    </div>

                    <div className="border-t border-slate-100 pt-4 space-y-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">Your Full Name *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g., Harish Chandra"
                          className="w-full text-xs rounded border border-slate-300 p-2.5 focus:border-corp-blue focus:outline-none bg-white"
                          value={donationForm.name}
                          onChange={(e) => setDonationForm({ ...donationForm, name: e.target.value })}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">Email ID *</label>
                          <input
                            type="email"
                            required
                            placeholder="harish@gmail.com"
                            className="w-full text-xs rounded border border-slate-300 p-2.5 focus:border-corp-blue focus:outline-none bg-white"
                            value={donationForm.email}
                            onChange={(e) => setDonationForm({ ...donationForm, email: e.target.value })}
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">PAN Card No. (For Tax Claim) *</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g., ABCDE1234F"
                            className="w-full text-xs rounded border border-slate-300 p-2.5 focus:border-corp-blue focus:outline-none bg-white font-mono uppercase"
                            value={donationForm.panNo}
                            onChange={(e) => setDonationForm({ ...donationForm, panNo: e.target.value })}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-lg flex gap-2 text-[10px] text-slate-500 leading-normal">
                      <Info className="w-4.5 h-4.5 text-corp-blue shrink-0 mt-0.5" />
                      <span>
                        Tax Exemption under Section 80G is eligible for individual and corporate contributors. On registering the pledge, our treasury team dispatches an official receipt with bank transfer guidelines.
                      </span>
                    </div>

                    <div className="pt-2 flex justify-end gap-2.5">
                      <button
                        type="button"
                        onClick={() => setIsDonationOpen(false)}
                        className="px-4 py-2 border border-slate-300 rounded text-slate-600 text-xs hover:bg-slate-50 font-bold"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2.5 bg-gold text-white hover:bg-[#B37612] text-xs font-bold rounded flex items-center justify-center gap-1"
                      >
                        Register Donation Pledge
                      </button>
                    </div>
                  </form>
                )}

              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
