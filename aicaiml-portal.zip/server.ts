import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';

// Simple in-memory storage to simulate CMS management in Phase 1
const cmsStore = {
  projects: [] as any[],
  events: [] as any[],
  news: [] as any[],
  enquiries: [] as any[],
  applications: [] as any[]
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON and URL-encoded parsers
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // API Route - Health Check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', serverTime: new Date().toISOString() });
  });

  // API Route - General Enquiry Form Submission with Honeypot Anti-Spam Check
  app.post('/api/enquiry/submit', (req, res) => {
    const { name, email, phone, message, honeypot } = req.body;

    // Honeypot spam check - if filled, silently reject or fail with a validation message
    if (honeypot && honeypot.trim() !== '') {
      console.warn('Spam submission detected via honeypot field.');
      return res.status(400).json({ error: 'Validation failed. Spam activity detected.' });
    }

    if (!name || !email || !message) {
      return res.status(400).json({ error: 'Name, email, and message are required.' });
    }

    const enquiryId = 'enq-' + Math.random().toString(36).substr(2, 9).toUpperCase();
    const newEnquiry = {
      id: enquiryId,
      name,
      email,
      phone,
      message,
      submittedAt: new Date().toISOString()
    };

    cmsStore.enquiries.push(newEnquiry);

    // Mock acknowledgement email sent
    const mockEmailTemplate = `
      Subject: [AICAIML] Enquiry Received - Ref No: ${enquiryId}
      To: ${email}
      
      Dear ${name},
      
      Thank you for reaching out to the All India Council for Artificial Intelligence and Machine Learning (AICAIML). We have received your enquiry regarding "AICAIML Network Forum".
      
      A representative from our executive team will review your message and get back to you within 2 business days.
      
      Your Enquiry Details:
      Reference ID: ${enquiryId}
      Message: "${message}"
      
      Sincerely,
      Executive Secretariat,
      AICAIML Council
    `;

    res.json({
      success: true,
      referenceId: enquiryId,
      message: 'Enquiry submitted successfully.',
      mockEmailSent: true,
      emailLog: mockEmailTemplate
    });
  });

  // API Route - Membership Form Submission with Honeypot Anti-Spam Check
  app.post('/api/membership/submit', (req, res) => {
    const { category, formData, honeypot } = req.body;

    if (honeypot && honeypot.trim() !== '') {
      console.warn('Spam submission detected on membership form.');
      return res.status(400).json({ error: 'Spam validation failed.' });
    }

    if (!category || !formData) {
      return res.status(400).json({ error: 'Category and form data are required.' });
    }

    const membershipNo = 'AIC-' + category.substring(0, 3).toUpperCase() + '-' + Math.floor(100000 + Math.random() * 900000);
    const applicationId = 'APP-' + Math.random().toString(36).substr(2, 9).toUpperCase();

    const application = {
      id: applicationId,
      membershipNo,
      category,
      formData,
      submittedAt: new Date().toISOString()
    };

    cmsStore.applications.push(application);

    // Draft elegant custom acknowledgement emails based on the membership categories
    let emailBody = '';
    const name = formData.studentName || formData.applicantName || formData.authorizedRepresentativeName || formData.institutionName || formData.universityName || 'Applicant';
    const email = formData.emailId || formData.email || 'applicant@aic-aiml.org';

    emailBody = `
      Subject: [AICAIML] Membership Application Submitted - No: ${membershipNo}
      To: ${email}
      
      Dear ${name},
      
      Thank you for applying for AICAIML ${category.toUpperCase()} membership with the All India Council for Artificial Intelligence and Machine Learning.
      
      Your application has been received and logged securely in our Council database.
      
      APPLICATION SUMMARY:
      - Application ID: ${applicationId}
      - Allocated Membership No. (Pending Verification): ${membershipNo}
      - Category: ${category.toUpperCase()}
      - Submission Date: ${new Date().toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' })}
      
      Our Membership Review Committee will verify the submitted details against academic or organizational registries. This process typically takes 3 to 5 business days. Once verified, we will issue your digital membership certificate and secure member credentials.
      
      Welcome to Indias premier AI/ML advancements ecosystem!
      
      Sincerely,
      Membership Board,
      All India Council for Artificial Intelligence & Machine Learning (AICAIML)
    `;

    res.json({
      success: true,
      applicationId,
      membershipNo,
      message: `Your ${category} application has been logged successfully.`,
      emailLog: emailBody
    });
  });

  // API Route - Event Interest Registration
  app.post('/api/events/register', (req, res) => {
    const { eventId, eventTitle, name, email, phone, organization, designation, honeypot } = req.body;

    if (honeypot && honeypot.trim() !== '') {
      return res.status(400).json({ error: 'Spam activity blocked.' });
    }

    if (!eventId || !name || !email) {
      return res.status(400).json({ error: 'Event details, Name and Email are required.' });
    }

    const registrationId = 'REG-' + Math.random().toString(36).substr(2, 9).toUpperCase();

    const emailBody = `
      Subject: [AICAIML] Registration Received - ${eventTitle}
      To: ${email}
      
      Dear ${name},
      
      We have registered your interest for "${eventTitle}" with AICAIML.
      
      REGISTRATION RECEIPT:
      - Ticket ID: ${registrationId}
      - Event: ${eventTitle}
      - Registrant: ${name} (${organization || 'Individual'})
      - Mode: Hybrid/Online Access link will be shared 24 hours prior to the event.
      
      We look forward to your active participation in advancing AI, Machine Learning, and Robotics in India.
      
      Best Regards,
      Events Secretariat, AICAIML
    `;

    res.json({
      success: true,
      registrationId,
      message: `Successfully registered interest for ${eventTitle}`,
      emailLog: emailBody
    });
  });

  // API Route - In-memory CMS simulation to support real runtime news updates!
  app.get('/api/news', (req, res) => {
    res.json(cmsStore.news);
  });

  app.post('/api/news/add', (req, res) => {
    const { title, summary, category, readTime } = req.body;
    if (!title || !summary) {
      return res.status(400).json({ error: 'Title and summary are required' });
    }
    const newArticle = {
      id: 'news-' + Date.now(),
      title,
      summary,
      date: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }),
      category: category || 'Announcement',
      readTime: readTime || '3 min read'
    };
    cmsStore.news.unshift(newArticle);
    res.json({ success: true, article: newArticle });
  });

  // Vite development integration or production serving
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Error starting server:', err);
});
